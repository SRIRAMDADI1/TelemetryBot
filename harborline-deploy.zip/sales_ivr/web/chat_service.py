"""Chat conversation → CallSession JSON → Sales IVR pipeline → customer summary."""

from __future__ import annotations

import re
import uuid
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from sales_ivr.agents.customer_presentation import (
    fallback_customer_summary,
    format_customer_reply,
    present_pipeline_result,
)
from sales_ivr.fixtures.loader import build_initial_state
from sales_ivr.llm import reset_llm_client
from sales_ivr.models import CallSession, CallerProfile, CallerUtterance, IVRState
from sales_ivr.models.enums import CallChannel
from sales_ivr.orchestrator import run_session
from sales_ivr.runtime import clear_resource_cache


class ChatStep(StrEnum):
    GREETING = "greeting"
    PHONE = "phone"
    STATE = "state"
    ZIP = "zip"
    NEED = "need"
    DETAILS = "details"
    CONFIRM = "confirm"
    DONE = "done"


PHONE_RE = re.compile(r"(\+?1?\s*[-.(]?\d{3}[-.)]?\s*\d{3}[-.]?\d{4})")
STATE_RE = re.compile(r"\b(CA|TX|NY|FL|IL|California|Texas|New York|Florida|Illinois)\b", re.I)
ZIP_RE = re.compile(r"\b(\d{5})(?:-\d{4})?\b")

STATE_MAP = {
    "california": "CA",
    "texas": "TX",
    "new york": "NY",
    "florida": "FL",
    "illinois": "IL",
}


@dataclass
class ChatSession:
    session_id: str
    step: ChatStep = ChatStep.GREETING
    phone: str | None = None
    state: str | None = None
    zip_code: str | None = None
    need_text: str | None = None
    details_text: str | None = None
    confirm_text: str | None = None
    messages: list[dict[str, str]] = field(default_factory=list)
    pipeline_result: dict[str, Any] | None = None


_SESSIONS: dict[str, ChatSession] = {}


def _normalize_phone(raw: str) -> str | None:
    match = PHONE_RE.search(raw)
    if not match:
        return None
    digits = re.sub(r"\D", "", match.group(1))
    if len(digits) == 10:
        digits = "1" + digits
    if len(digits) == 11 and digits.startswith("1"):
        return digits
    return None


def _normalize_state(raw: str) -> str | None:
    match = STATE_RE.search(raw)
    if not match:
        return None
    token = match.group(1)
    if len(token) == 2:
        return token.upper()
    return STATE_MAP.get(token.lower())


def _extract_zip(raw: str) -> str | None:
    match = ZIP_RE.search(raw)
    return match.group(1) if match else None


def create_chat() -> ChatSession:
    chat = ChatSession(session_id=str(uuid.uuid4()))
    welcome = (
        "Welcome to Harborline Insurance. I'm your quote assistant "
        "(chat stand-in until voice IVR is live). "
        "I'll ask a few questions, then prepare your quote summary.\n\n"
        "What's the best phone number to reach you? "
        "Demo tip: try 555-123-4001 for an existing customer."
    )
    chat.messages.append({"role": "assistant", "content": welcome})
    chat.step = ChatStep.PHONE
    _SESSIONS[chat.session_id] = chat
    return chat


def get_chat(session_id: str) -> ChatSession | None:
    return _SESSIONS.get(session_id)


def _build_call_session(chat: ChatSession) -> CallSession:
    utterances: list[CallerUtterance] = []
    turn = 0
    if chat.need_text:
        utterances.append(CallerUtterance(turn=turn, text=chat.need_text, confidence=0.98))
        turn += 1
    if chat.details_text:
        utterances.append(CallerUtterance(turn=turn, text=chat.details_text, confidence=0.96))
        turn += 1
    confirm = chat.confirm_text or "Yes, that sounds good. I'll proceed."
    utterances.append(CallerUtterance(turn=turn, text=confirm, confidence=0.99))

    phone = chat.phone or "15559876543"
    return CallSession(
        session_id=f"web-{chat.session_id[:8]}",
        caller_phone=phone,
        channel=CallChannel.WEB_CHAT,
        language="en-US",
        utterances=utterances,
        dtmf_digits="1",
        caller_profile=CallerProfile(
            zip_code=chat.zip_code,
            state=chat.state,
        ),
    )


def _coerce_state(result: IVRState | dict) -> IVRState:
    if isinstance(result, IVRState):
        return result
    return IVRState.model_validate(result)


def _build_pipeline_payload(result: IVRState, call: CallSession) -> dict[str, Any]:
    session = result.session
    payload: dict[str, Any] = {
        "status": session.status.value,
        "intent": session.intent.value,
        "intent_confidence": session.intent_confidence,
        "caller_type": session.caller_type.value,
        "customer_id": session.caller_profile.customer_id,
        "verified": session.caller_profile.verified,
        "product_id": session.selected_product_id,
        "quote": None,
        "compliance_passed": (
            session.compliance.compliance_passed if session.compliance else None
        ),
        "handoff": None,
        "llm_calls": len(result.llm_usage),
        "total_tokens": sum(u.total_tokens for u in result.llm_usage),
        "audit": [
            {"node": e.node.value, "status": e.status, "message": e.message}
            for e in result.audit_trail
        ],
        "session_json": call.model_dump(mode="json"),
        "ivr_responses": [r.text for r in session.ivr_responses],
        "customer_summary": None,
    }
    if session.quote:
        payload["quote"] = {
            "monthly": session.quote.quote_amount_monthly,
            "annual": session.quote.quote_amount_annual,
            "summary": session.quote.coverage_summary,
            "script": session.quote.ivr_script,
            "product_line": session.quote.product_line.value,
        }
    if session.handoff:
        payload["handoff"] = {
            "queue": session.handoff.recommended_queue.value,
            "priority": session.handoff.priority,
            "summary": session.handoff.summary,
        }
    return payload


def run_pipeline_for_chat(chat: ChatSession) -> dict[str, Any]:
    clear_resource_cache()
    reset_llm_client()
    call = _build_call_session(chat)
    result = _coerce_state(run_session(build_initial_state(call)))
    payload = _build_pipeline_payload(result, call)

    try:
        summary = present_pipeline_result(payload, state=result)
    except Exception:
        summary = fallback_customer_summary(payload)

    payload["customer_summary"] = summary.model_dump(mode="json")
    payload["llm_calls"] = len(result.llm_usage)
    payload["total_tokens"] = sum(u.total_tokens for u in result.llm_usage)
    payload["customer_reply"] = format_customer_reply(summary)
    return payload


def handle_user_message(chat: ChatSession, text: str) -> dict[str, Any]:
    text = (text or "").strip()
    chat.messages.append({"role": "user", "content": text})
    reply = ""
    quote_ready = False

    if chat.step == ChatStep.PHONE:
        phone = _normalize_phone(text)
        if not phone:
            reply = "I need a US phone number (10 digits). Example: 555-123-4001"
        else:
            chat.phone = phone
            chat.step = ChatStep.STATE
            reply = (
                "Thanks. Which state are you in? "
                "We currently quote in CA, TX, NY, FL, and IL."
            )

    elif chat.step == ChatStep.STATE:
        state = _normalize_state(text)
        if not state:
            reply = "Please enter a supported state code or name (CA, TX, NY, FL, IL)."
        else:
            chat.state = state
            chat.step = ChatStep.ZIP
            reply = f"Got it — {state}. What's your 5-digit ZIP code?"

    elif chat.step == ChatStep.ZIP:
        zip_code = _extract_zip(text)
        if not zip_code:
            reply = "Please enter a 5-digit ZIP code (example: 90210)."
        else:
            chat.zip_code = zip_code
            chat.step = ChatStep.NEED
            reply = (
                "What can I help with today? For example:\n"
                "• \"I'd like a quote for auto insurance\"\n"
                "• \"I need homeowners insurance\"\n"
                "• \"Looking for renters insurance\"\n"
                "• \"I need to speak to an agent about a claim\""
            )

    elif chat.step == ChatStep.NEED:
        if len(text) < 5:
            reply = "Tell me a bit more about what you need (auto, home, life, renters, claims…)."
        else:
            chat.need_text = text
            lower = text.lower()
            if any(k in lower for k in ("claim", "billing", "speak", "agent", "human", "person")):
                chat.details_text = text
                chat.confirm_text = text
                chat.step = ChatStep.DONE
                chat.pipeline_result = run_pipeline_for_chat(chat)
                quote_ready = True
                reply = chat.pipeline_result["customer_reply"]
            else:
                chat.step = ChatStep.DETAILS
                reply = (
                    "Any details that affect the quote? "
                    "For auto: vehicle year and annual miles. "
                    "For home: approximate home value. "
                    "Or say \"skip\" to continue."
                )

    elif chat.step == ChatStep.DETAILS:
        chat.details_text = None if text.lower().strip() in {"skip", "none", "n/a"} else text
        chat.step = ChatStep.CONFIRM
        reply = (
            "Ready to prepare your preliminary quote. "
            "Reply \"yes\" / \"proceed\" to accept a quote, "
            "or \"too expensive\" to ask about a lower-priced option."
        )

    elif chat.step == ChatStep.CONFIRM:
        chat.confirm_text = text
        chat.step = ChatStep.DONE
        chat.pipeline_result = run_pipeline_for_chat(chat)
        quote_ready = True
        reply = chat.pipeline_result["customer_reply"]

    else:
        reply = (
            "This chat session is complete. Start a new chat to run another quote. "
            "Voice IVR will replace this chatbot later."
        )

    chat.messages.append({"role": "assistant", "content": reply})
    return {
        "session_id": chat.session_id,
        "reply": reply,
        "step": chat.step.value,
        "done": chat.step == ChatStep.DONE,
        "quote_ready": quote_ready,
        "result": chat.pipeline_result,
    }
