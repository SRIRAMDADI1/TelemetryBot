const workspace = document.getElementById("workspace");
const messagesEl = document.getElementById("messages");
const resultEmpty = document.getElementById("resultEmpty");
const resultBody = document.getElementById("resultBody");
const jsonDetails = document.getElementById("jsonDetails");
const sessionJson = document.getElementById("sessionJson");
const stepPill = document.getElementById("stepPill");
const startBtn = document.getElementById("startBtn");
const newBtn = document.getElementById("newBtn");
const form = document.getElementById("chatForm");
const input = document.getElementById("input");

let sessionId = null;

function escapeHtml(text) {
  return String(text)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function addBubble(role, content) {
  const div = document.createElement("div");
  div.className = `bubble ${role}`;
  div.textContent = content.replace(/\*\*(.*?)\*\*/g, "$1");
  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function renderResult(result) {
  if (!result) {
    resultEmpty.hidden = false;
    resultBody.hidden = true;
    jsonDetails.hidden = true;
    return;
  }
  resultEmpty.hidden = true;
  resultBody.hidden = false;
  jsonDetails.hidden = false;

  const summary = result.customer_summary || {};
  const quote = result.quote;
  const highlights = (summary.highlights || [])
    .map((item) => `<li>${escapeHtml(item)}</li>`)
    .join("");
  const nextSteps = (summary.next_steps || [])
    .map((item) => `<li>${escapeHtml(item)}</li>`)
    .join("");

  resultBody.innerHTML = `
    <div class="summary-card">
      <h3>${escapeHtml(summary.headline || "Your Harborline update")}</h3>
      <p class="summary-body">${escapeHtml(summary.body || result.customer_reply || "")}</p>
      ${highlights ? `<ul class="summary-list">${highlights}</ul>` : ""}
      ${
        quote
          ? `<div class="metric quote"><span class="label">Estimated monthly</span><span class="value">$${Number(quote.monthly).toFixed(2)}</span></div>
             <div class="metric"><span class="label">Estimated annual</span><span class="value">$${Number(quote.annual).toFixed(2)}</span></div>`
          : ""
      }
      ${nextSteps ? `<p class="summary-label">Next steps</p><ul class="summary-list">${nextSteps}</ul>` : ""}
      ${summary.disclaimer ? `<p class="summary-disclaimer">${escapeHtml(summary.disclaimer)}</p>` : ""}
    </div>
  `;

  sessionJson.textContent = JSON.stringify(
    {
      session_json: result.session_json,
      status: result.status,
      intent: result.intent,
      product_id: result.product_id,
      quote: result.quote,
      handoff: result.handoff,
      llm_calls: result.llm_calls,
      total_tokens: result.total_tokens,
    },
    null,
    2
  );
}

async function startChat() {
  const res = await fetch("/api/chat/start", { method: "POST" });
  if (!res.ok) throw new Error("Could not start chat");
  const data = await res.json();
  sessionId = data.session_id;
  messagesEl.innerHTML = "";
  addBubble("assistant", data.reply);
  stepPill.textContent = data.step;
  workspace.hidden = false;
  newBtn.hidden = false;
  startBtn.textContent = "Chat open";
  renderResult(null);
  input.focus();
}

async function sendMessage(message) {
  const res = await fetch("/api/chat/message", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ session_id: sessionId, message }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || "Message failed");
  }
  return res.json();
}

startBtn.addEventListener("click", async () => {
  try {
    startBtn.disabled = true;
    await startChat();
  } catch (err) {
    alert(err.message);
  } finally {
    startBtn.disabled = false;
  }
});

newBtn.addEventListener("click", async () => {
  await startChat();
});

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!sessionId) return;
  const message = input.value.trim();
  if (!message) return;
  input.value = "";
  addBubble("user", message);
  try {
    input.disabled = true;
    const data = await sendMessage(message);
    addBubble("assistant", data.reply);
    stepPill.textContent = data.step;
    if (data.result) renderResult(data.result);
  } catch (err) {
    addBubble("assistant", `Sorry — ${err.message}`);
  } finally {
    input.disabled = false;
    input.focus();
  }
});
