"""Sales IVR — insurance sales IVR platform base package."""

__version__ = "0.1.0"
